/* ===================================================
   BANK SOAL BIOLOGI KELAS 10 SEMESTER 2 (TOTAL 60 SOAL)
   Sesuai Materi Bab 7: Keanekaragaman Makhluk Hidup, 
   Klasifikasi, Peranan, & Interaksi di Alam
   =================================================== */

const bankSoalBesar = [
  // --- 1. KEANEKARAGAMAN HAYATI (GEN, SPESIES, EKOSISTEM) ---
  {
    q: "Keanekaragaman warna bunga mawar (merah, putih, kuning) merupakan contoh keanekaragaman tingkat...",
    answers: ["Gen", "Spesies", "Ekosistem", "Komunitas"],
    correct: 0
  },
  {
    q: "Kucing, harimau, dan singa berada dalam satu familia yang sama tetapi berbeda spesies. Hal ini menunjukkan keanekaragaman tingkat...",
    answers: ["Gen", "Jenis / Spesies", "Ekosistem", "Populasi"],
    correct: 1
  },
  {
    q: "Hutan hujan tropis, padang rumput, dan terumbu karang merupakan contoh keanekaragaman tingkat...",
    answers: ["Gen", "Jenis", "Ekosistem", "Individu"],
    correct: 2
  },
  {
    q: "Variasi bentuk, warna, dan rasa pada mangga arumanis, mangga manalagi, dan mangga golek merupakan keanekaragaman tingkat...",
    answers: ["Gen", "Spesies", "Ekosistem", "Filum"],
    correct: 0
  },
  {
    q: "Keanekaragaman hayati yang menunjukkan variasi genetik dalam satu spesies yang menyebabkan perbedaan sifat antarindividu disebut keanekaragaman tingkat...",
    answers: ["Gen", "Spesies", "Ekosistem", "Komunitas"],
    correct: 0
  },
  {
    q: "Berikut ini yang merupakan contoh keanekaragaman tingkat ekosistem adalah...",
    answers: ["Mawar merah dan mawar putih", "Kelapa, pinang, dan palem", "Hutan hujan, laut, dan gurun", "Kucing anggora dan kucing persia"],
    correct: 2
  },
  {
    q: "Berikut ini yang termasuk tanaman endemik khas Indonesia dari Bengkulu yang terkenal dengan bunga raksasanya adalah...",
    answers: ["Rafflesia arnoldii", "Bunga Melati", "Anggrek Hitam", "Kantung Semar"],
    correct: 0
  },
  {
    q: "Garis khayal yang membatasi wilayah fauna tipe Asiatis dengan wilayah Peralihan adalah garis...",
    answers: ["Weber", "Wallace", "Khatulistiwa", "Ekuator"],
    correct: 1
  },
  {
    q: "Hewan endemik Indonesia seperti Anoa dan Babirusa dapat ditemukan di wilayah fauna tipe...",
    answers: ["Asiatis", "Australis", "Peralihan", "Oriental"],
    correct: 2
  },
  {
    q: "Usaha pelestarian makhluk hidup yang dilakukan di luar habitat aslinya disebut pelestarian...",
    answers: ["In situ", "Ex situ", "Domestikasi", "Konservasi alam"],
    correct: 1
  },

  // --- 2. KLASIFIKASI MAKHLUK HIDUP & TINGKAT TAKSONOMI ---
  {
    q: "Tujuan utama dari pengelompokan (klasifikasi) makhluk hidup adalah untuk...",
    answers: ["Membuat kelompok baru", "Memudahkan mempelajari ciri-ciri makhluk hidup", "Menghitung jumlah makhluk hidup", "Memusnahkan hewan berbahaya"],
    correct: 1
  },
  {
    q: "Dasar utama yang digunakan dalam melakukan klasifikasi makhluk hidup adalah...",
    answers: ["Jumlah populasi di alam", "Persamaan dan perbedaan ciri fisik/morfologi", "Manfaat bagi manusia", "Tempat hidupnya saja"],
    correct: 1
  },
  {
    q: "Urutan tingkat taksonomi hewan dari yang tertinggi hingga yang terendah adalah...",
    answers: ["Kingdom - Filum - Kelas - Ordo - Famili - Genus - Spesies", "Kingdom - Divisio - Kelas - Ordo - Famili - Genus - Spesies", "Spesies - Genus - Famili - Ordo - Kelas - Filum - Kingdom", "Kingdom - Kelas - Filum - Ordo - Famili - Genus - Spesies"],
    correct: 0
  },
  {
    q: "Tingkatan taksonomi untuk tumbuhan yang setara dengan tingkatan Filum pada hewan adalah...",
    answers: ["Ordo", "Divisio", "Kelas", "Famili"],
    correct: 1
  },
  {
    q: "Tingkat takson terkecil yang anggotanya memiliki banyak persamaan dan dapat melakukan perkawinan menghasilkan keturunan fertil adalah...",
    answers: ["Kingdom", "Genus", "Famili", "Spesies"],
    correct: 3
  },
  {
    q: "Pada penulisan nama ilmiah singa yaitu “Panthera leo”, kata “Panthera” menunjukkan tingkatan takson...",
    answers: ["Spesies", "Genus", "Famili", "Ordo"],
    correct: 1
  },
  {
    q: "Salah satu manfaat dari klasifikasi makhluk hidup dalam bidang ilmiah adalah...",
    answers: ["Mengetahui hubungan kekerabatan antar makhluk hidup", "Membuat nama baru untuk semua hewan", "Memperbanyak spesies di alam", "Mencegah kepunahan tumbuhan"],
    correct: 0
  },
  {
    q: "Harimau (Panthera tigris) dan Singa (Panthera leo) memiliki tingkat takson yang sama hingga tingkat...",
    answers: ["Spesies", "Genus", "Subspesies", "Varietas"],
    correct: 1
  },
  {
    q: "Urutan taksonomi yang berada di antara Kelas dan Famili adalah...",
    answers: ["Filum", "Ordo", "Genus", "Spesies"],
    correct: 1
  },
  {
    q: "Sistem tata nama ganda untuk penulisan nama ilmiah makhluk hidup disebut...",
    answers: ["Kunci dikotom", "Binomial nomenklatur", "Taksonomi", "Sistem kladogram"],
    correct: 1
  },

  // --- 3. KOMPONEN EKOSISTEM (BIOTIK & ABIOTIK) ---
  {
    q: "Komponen abiotik dalam ekosistem yang menjadi sumber energi utama bagi kehidupan di bumi adalah...",
    answers: ["Air", "Tanah", "Cahaya matahari", "Udara"],
    correct: 2
  },
  {
    q: "Berikut ini yang tergolong ke dalam komponen biotik dalam suatu ekosistem adalah...",
    answers: ["Suhu, air, dan tanah", "Tumbuhan, hewan, dan bakteri", "Cahaya matahari dan udara", "Kelembapan dan pH tanah"],
    correct: 1
  },
  {
    q: "Faktor abiotik yang sangat mempengaruhi tingkat kelembapan dan proses penguapan air di suatu lingkungan adalah...",
    answers: ["Suhu dan cahaya matahari", "Jenis batuan", "Produsen", "Pengurai"],
    correct: 0
  },
  {
    q: "Air, udara, tanah, dan suhu termasuk ke dalam komponen ekosistem kategori...",
    answers: ["Biotik", "Abiotik", "Organik", "Biologi"],
    correct: 1
  },
  {
    q: "Jamur dan bakteri yang terdapat di dalam tanah berfungsi sebagai komponen...",
    answers: ["Produsen", "Konsumen primer", "Pengurai / Dekomposer", "Predator puncak"],
    correct: 2
  },

  // --- 4. PERAN MAKHLUK HIDUP DALAM EKOSISTEM ---
  {
    q: "Organisme yang mampu membuat makanannya sendiri melalui proses fotosintesis disebut...",
    answers: ["Produsen / Autotrof", "Konsumen / Heterotrof", "Pengurai / Dekomposer", "Detritivor"],
    correct: 0
  },
  {
    q: "Hewan herbivora yang memakan produsen secara langsung dalam rantai makanan menduduki peran sebagai...",
    answers: ["Produsen", "Konsumen I (Primer)", "Konsumen II (Sekunder)", "Pengurai"],
    correct: 1
  },
  {
    q: "Organisme yang memperoleh energi dengan cara menguraikan sisa-sisa bahan organik menjadi unsur hara adalah...",
    answers: ["Tumbuhan hijau", "Karnivora", "Pengurai (Jamur & Bakteri)", "Herbivora"],
    correct: 2
  },
  {
    q: "Organisme yang memakan hancuran atau sisa-sisa bahan organik (seperti cacing tanah) disebut...",
    answers: ["Detritivor", "Dekomposer", "Herbivora", "Karnivora"],
    correct: 0
  },
  {
    q: "Predator alami dan serangga penyerbuk dalam ekosistem memiliki peran penting sebagai...",
    answers: ["Pengendali keseimbangan ekosistem", "Produsen utama", "Dekomposer tanah", "Komponen abiotik"],
    correct: 0
  },
  {
    q: "Hewan pemakan daging yang memangsa hewan herbivora bertindak sebagai...",
    answers: ["Produsen", "Konsumen I", "Konsumen II / Karnivora", "Pengurai"],
    correct: 2
  },
  {
    q: "Contoh organisme yang berperan sebagai produsen di ekosistem perairan adalah...",
    answers: ["Zooplankton", "Fitoplankton / Alga", "Ikan kecil", "Kepiting"],
    correct: 1
  },
  {
    q: "Organisme heterotrof adalah makhluk hidup yang...",
    answers: ["Dapat membuat makanan sendiri", "Tidak dapat membuat makanan sendiri", "Tidak membutuhkan air", "Selalu bersifat dekomposer"],
    correct: 1
  },

  // --- 5. INTERAKSI ANTAR MAKHLUK HIDUP & JARINGS-JARING MAKANAN ---
  {
    q: "Interaksi antara singa dan rusa di mana singa memangsa rusa disebut...",
    answers: ["Kompetisi", "Predasi", "Simbiosis", "Netralisme"],
    correct: 1
  },
  {
    q: "Persaingan antara dua populasi hewan untuk memperebutkan sumber daya yang terbatas disebut...",
    answers: ["Predasi", "Kompetisi", "Simbiosis", "Netralisme"],
    correct: 1
  },
  {
    q: "Hubungan antarorganisme yang saling menguntungkan kedua belah pihak disebut simbiosis...",
    answers: ["Mutualisme", "Komensalisme", "Parasitisme", "Amensalisme"],
    correct: 0
  },
  {
    q: "Hubungan antara tanaman anggrek yang menempel pada pohon inang tanpa merugikan inangnya disebut simbiosis...",
    answers: ["Mutualisme", "Komensalisme", "Parasitisme", "Predasi"],
    correct: 1
  },
  {
    q: "Interaksi antara benalu yang menyerap nutrisi dari pohon host/inang merupakan contoh simbiosis...",
    answers: ["Mutualisme", "Komensalisme", "Parasitisme", "Netralisme"],
    correct: 2
  },
  {
    q: "Interaksi antara lebah dan bunga tanaman merupakan contoh dari simbiosis...",
    answers: ["Mutualisme", "Komensalisme", "Parasitisme", "Predasi"],
    correct: 0
  },
  {
    q: "Kumpulan dari beberapa rantai makanan yang saling berhubungan dan bersilangan disebut...",
    answers: ["Piramida makanan", "Jaring-jaring makanan", "Tingkat trofik", "Daur ekologi"],
    correct: 1
  },
  {
    q: "Dalam alur rantai makanan: Tumbuhan -> Belalang -> Tikus -> Ular -> Elang. Ular berperan sebagai...",
    answers: ["Produsen", "Konsumen I", "Konsumen II", "Konsumen III / Predator"],
    correct: 3
  },
  {
    q: "Jika populasi ular pada jaring-jaring makanan menurun drastis, dampak langsung yang kemungkinan terjadi adalah...",
    answers: ["Populasi tikus meningkat", "Populasi belalang menurun", "Tumbuhan habis seketika", "Populasi elang bertambah pesat"],
    correct: 0
  },
  {
    q: "Interaksi yang seimbang antar komponen dalam ekosistem sangat penting untuk menjaga...",
    answers: ["Kepunahan konsumen", "Keberlanjutan dan keseimbangan ekosistem", "Penurunan jumlah produsen", "Dominasi satu spesies saja"],
    correct: 1
  },

  // --- SOAL PENGUAT & EVALUASI BAB 7 ---
  {
    q: "Suatu kelompok individu sejenis yang hidup di tempat dan waktu yang sama dinamakan...",
    answers: ["Individu", "Populasi", "Komunitas", "Ekosistem"],
    correct: 1
  },
  {
    q: "Kumpulan berbagai populasi yang saling berinteraksi di suatu wilayah tertentu disebut...",
    answers: ["Individu", "Biosfer", "Komunitas", "Ekosistem"],
    correct: 2
  },
  {
    q: "Sistem hubungan timbal balik antara makhluk hidup dengan lingkungan abiotiknya dinamakan...",
    answers: ["Komunitas", "Populasi", "Ekosistem", "Biosfer"],
    correct: 2
  },
  {
    q: "Contoh interaksi komensalisme di laut adalah hubungan antara...",
    answers: ["Ikan hiu dan ikan remora", "Ikan paus dan zooplankton", "Ikan kecil dan gurita", "Anemon laut dan ikan badut yang saling menguntungkan"],
    correct: 0
  },
  {
    q: "Organisme yang berperan sebagai pengurai dalam tanah adalah...",
    answers: ["Cacing tanah dan ular", "Bakteri pembusuk dan jamur", "Rumput dan lumut", "Belalang dan ulat"],
    correct: 1
  },
  {
    q: "Berikut ini yang merupakan tingkatan takson paling spesifik (paling bawah) adalah...",
    answers: ["Kingdom", "Famili", "Genus", "Spesies"],
    correct: 3
  },
  {
    q: "Nama ilmuwan yang dikenal sebagai Bapak Taksonomi Modern penemu sistem Binomial Nomenklatur adalah...",
    answers: ["Charles Darwin", "Carolus Linnaeus", "Gregor Mendel", "Robert Hooke"],
    correct: 1
  },
  {
    q: "Simbiosis antara jamur dan ganggang yang membentuk Lichenes (Lumut Kerak) bersifat...",
    answers: ["Mutualisme", "Komensalisme", "Parasitisme", "Predasi"],
    correct: 0
  },
  {
    q: "Hewan yang hanya memakan bahan tumbuhan dinamakan...",
    answers: ["Karnivora", "Herbivora", "Omnivora", "Detritivor"],
    correct: 1
  },
  {
    q: "Hubungan antara dua spesies di mana satu spesies dirugikan dan spesies lain tidak dipengaruhi dinamakan...",
    answers: ["Amensalisme", "Komensalisme", "Mutualisme", "Parasitisme"],
    correct: 0
  },
  {
    q: "Dalam jaring-jaring makanan, organisme yang menduduki tingkat trofik pertama selalu berupa...",
    answers: ["Herbivora", "Karnivora", "Produsen / Tumbuhan hijau", "Pengurai"],
    correct: 2
  },
  {
    q: "Ular yang memangsa tikus di area persawahan merupakan bentuk interaksi...",
    answers: ["Kompetisi", "Predasi", "Simbiosis", "Netralisme"],
    correct: 1
  },
  {
    q: "Taman Nasional Komodo yang terletak di Nusa Tenggara Timur tergolong kawasan fauna tipe...",
    answers: ["Asiatis", "Peralihan", "Australis", "Oriental"],
    correct: 1
  },
  {
    q: "Interaksi antara dua populasi yang saling tidak mempengaruhi satu sama lain disebut...",
    answers: ["Netralisme", "Kompetisi", "Predasi", "Simbiosis"],
    correct: 0
  },
  {
    q: "Ciri fauna tipe Australis yang berada di Indonesia bagian timur adalah...",
    answers: ["Banyak mamalia berukuran sangat besar", "Banyak hewan berkantung dan burung berwarna cerah", "Tidak ada reptil", "Sama persis dengan fauna Benua Asia"],
    correct: 1
  },
  {
    q: "Semua makhluk hidup di bumi beserta lingkungan tempat tinggalnya membentuk tingkatan organisasi tertinggi yang disebut...",
    answers: ["Komunitas", "Ekosistem", "Biosfer", "Populasi"],
    correct: 2
  }
];